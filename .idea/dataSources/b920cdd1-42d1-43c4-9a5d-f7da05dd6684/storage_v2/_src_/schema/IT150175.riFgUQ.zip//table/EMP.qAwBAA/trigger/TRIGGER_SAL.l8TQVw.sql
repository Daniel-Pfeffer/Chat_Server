create trigger TRIGGER_SAL
  before insert or update of SAL
  on EMP
  for each row
  when (old.job not in ('MANAGER', 'PRESIDENT'))
DECLARE
    salgradeRec salgrade%ROWTYPE;
BEGIN
    select * into salgradeRec from salgrade where :old.sal between losal and hisal;

    if :new.sal not between salgradeRec.losal and salgradeRec.hisal then
    raise_application_error(-20000, 'Neues Gehalt für ' || :old.ename || 'darf max. ' ||TO_CHAR(salgradeRec.hisal) || ' betragen.');
    end if;
END;
/


create trigger AUDIT_SAL
  after update of SAL
  on EMP
  for each row
declare
    gommunism BOOLEAN:=true;
      BEGIN
         INSERT INTO emp_log VALUES( IDLOG.nextval,sysdate);
END;
/


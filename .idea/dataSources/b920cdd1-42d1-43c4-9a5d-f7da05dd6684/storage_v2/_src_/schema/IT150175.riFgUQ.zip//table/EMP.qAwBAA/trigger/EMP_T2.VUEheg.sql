create trigger EMP_T2
  before insert or update of HIREDATE
  on EMP
  for each row
declare
  countRec INTEGER := 0;
begin
  select count(*) into countRec from emp where to_char(HIREDATE, 'MM-YYYY') = to_char(:new.HIREDATE, 'MM_YYYY');
  if countRec > 1 then
    raise_application_error(-88420, 'Nur ein emplayee pro monat einstellbar');
  end if;
end;
/

